/**
 * Обстрел сложными случаями: каждая сцена на каждом рельефе.
 *
 * Смотреть на одну красивую сцену бессмысленно — ломается на некрасивых.
 * Здесь цифры, а не картинки: цифры видно все сразу и они не врут.
 *
 * Запуск: npm run scenes            — все сцены на всех рельефах
 *         npm run scenes крест      — только названные сцены
 */

import { SCENES } from '../src/scenes.ts';
import { buildWorld } from '../src/world/world.ts';
import { TERRAINS } from '../src/world/terrain.ts';
import { DEFAULT_VARIANT, VARIANTS, buildSurface, pokeThrough } from '../src/surface/index.ts';
import { inspect, problems } from './inspect.ts';
import { crossingBorders } from './edges.ts';

const args = process.argv.slice(2);
const variant = args.find((a) => VARIANTS[a.toUpperCase()] !== undefined)?.toUpperCase() ?? DEFAULT_VARIANT;
const wanted = args.filter((a) => SCENES[a] !== undefined);
const names = wanted.length > 0 ? wanted : Object.keys(SCENES);
const terrains = Object.keys(TERRAINS);

console.log(`вариант ${VARIANTS[variant].label}\n`);

const head = ['сцена', 'рельеф', 'дорог', 'узлов', 'треуг.', 'дырок', 'изнанка', 'плоских', 'игла', 'асф/трот', 'торчит', 'мс'];
console.log(head.map((h, i) => h.padEnd([11, 9, 6, 6, 8, 7, 8, 8, 6, 8, 8, 6][i])).join(''));
console.log('─'.repeat(87));

const failures: string[] = [];
let worstTime = 0;
let worstPoke = 0;

for (const name of names) {
  const roads = SCENES[name];
  if (!roads) {
    console.log(`нет сцены «${name}»`);
    continue;
  }
  for (const terrain of terrains) {
    const started = performance.now();
    let line: string;
    try {
      const world = buildWorld(roads, terrain);
      const surface = buildSurface(world, variant);
      const ms = performance.now() - started;
      worstTime = Math.max(worstTime, ms);
      const r = inspect(world, surface);
      const poke = variant === 'B' ? pokeThrough(world) : { worst: 0, share: 0 };
      worstPoke = Math.max(worstPoke, poke.worst);
      // Обязательные рёбра, которые пересекаются, триангуляция выполнить
      // не может — и выдаёт налезающие треугольники. Ловим это ДО того,
      // как оно превратится в дырку, иначе искать причину придётся с конца.
      if (variant === 'A') {
        const tangled = crossingBorders(world);
        if (tangled.count > 0) {
          failures.push(`${name}/${terrain}: ${tangled.count} пересечений обязательных рёбер — ${tangled.where[0]}`);
        }
      }
      line = [
        name.padEnd(11),
        TERRAINS[terrain].label.padEnd(9),
        String(world.shapes.length).padEnd(6),
        String(world.junctions.length).padEnd(6),
        String(r.triangles).padEnd(8),
        String(r.holes).padEnd(7),
        String(r.downFacing).padEnd(8),
        String(r.flat).padEnd(8),
        r.worstAspect.toFixed(0).padEnd(6),
        `${(r.asphalt * 100).toFixed(0)}/${(r.sidewalk * 100).toFixed(0)}%`.padEnd(8),
        (poke.worst > 0 ? `${poke.worst.toFixed(2)}м` : '—').padEnd(8),
        ms.toFixed(0).padEnd(6),
      ].join('');
      for (const p of problems(r)) failures.push(`${name}/${terrain}: ${p}`);
    } catch (error) {
      line = `${name.padEnd(11)}${TERRAINS[terrain].label.padEnd(9)}ПАДЕНИЕ: ${String(error instanceof Error ? error.message : error).slice(0, 60)}`;
      failures.push(`${name}/${terrain}: падение — ${String(error instanceof Error ? error.message : error).slice(0, 70)}`);
    }
    console.log(line);
  }
}

console.log('─'.repeat(87));
console.log(`самая долгая сборка: ${worstTime.toFixed(0)} мс`);
if (worstPoke > 0) console.log(`земля торчит сквозь асфальт: до ${worstPoke.toFixed(2)} м`);
/**
 * ДОЛГ — потолок, а не цель.
 *
 * До 16 сентября предел уклона полотна стоял вчетверо выше настоящего,
 * и «все сцены целы» означало «никто не круче 32% при пределе 8%». За этим
 * потолком пряталось восемь настоящих поломок, из них шесть — тротуары
 * до 24%, по которым нельзя пройти. Прибор починен, и долг теперь виден.
 *
 * Чинится он не здесь: уклон полотна держит высотный решатель в `world/`,
 * а тротуар — полка в `surface/`. Обе папки заморожены словом Алекса.
 * Поэтому долг назван числом: станет больше — проверка упадёт.
 *
 * Запуск: npm run scenes долг 8
 */
const долгАргумент = args.indexOf('долг');
const ДОЛГ = долгАргумент >= 0 ? Number(args[долгАргумент + 1] ?? 0) : 0;

if (failures.length > ДОЛГ) {
  console.log(`\nПОЛОМОК: ${failures.length}${ДОЛГ > 0 ? ` при допустимом долге ${ДОЛГ}` : ''}`);
  for (const f of failures) console.log('  ✗ ' + f);
  process.exit(1);
}
if (failures.length > 0) {
  console.log(`\nизвестный долг: ${failures.length} из ${ДОЛГ} — это потолок, а не цель`);
  for (const f of failures) console.log('  · ' + f);
  process.exit(0);
}
console.log('✓ все сцены целы');
