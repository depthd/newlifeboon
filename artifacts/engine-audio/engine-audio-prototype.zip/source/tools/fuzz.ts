/**
 * Обстрел случайными постройками.
 *
 * Отказов больше не бывает: мир принимает любую постройку. Поэтому здесь
 * только два исхода — целая или сломанная.
 *
 * Смысл: не надеяться, что игрок не наткнётся на поломку, а самим построить
 * тысячу нелепых дорожных сетей и посмотреть, где мир рвётся. Глаз так не может,
 * а это считается за минуту и без браузера.
 *
 * Запуск: npm run fuzz [сколько построек]
 */

import type { Point2, Road } from '../src/world/road.ts';
import { roadTypeForLanes } from '../src/world/road.ts';
import { buildWorld } from '../src/world/world.ts';
import { buildSurface } from '../src/surface/index.ts';
import { TERRAINS, МИН_ПОЛМИРА } from '../src/world/terrain.ts';
import { inspect, problems } from './inspect.ts';
import { crossingBorders } from './edges.ts';

const TRIES = Number(process.argv[2] ?? 200);
/** Одно зерно подробно: `npm run fuzz -- 0 48`. */
const ONLY = process.argv[3] === 'долг' ? 0 : Number(process.argv[3] ?? 0);
/**
 * Долг — сколько поломок уже записано в «Известные дыры» и потому допускается:
 * `npm run fuzz 250 долг 5`. Это потолок долга, а не цель. Стало больше —
 * падаем: значит сломали что-то новое. Стало меньше — говорим, что долг пора
 * опустить, иначе он тихо превратится в разрешение ломать.
 */
const DEBT = process.argv[3] === 'долг' ? Number(process.argv[4] ?? 0) : 0;
/** Обстрел идёт, только когда файл запустили. Постройки нужны и другим. */
const RUNNING = process.argv[1]?.endsWith('fuzz.ts') ?? false;

/** Свой генератор случайных чисел: одно и то же зерно даёт один и тот же мир. */
function rng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export function layout(seed: number): { roads: Road[]; terrain: string } {
  const rand = rng(seed);
  const names = Object.keys(TERRAINS);
  const terrain = names[Math.floor(rand() * names.length)];
  const count = 1 + Math.floor(rand() * 4);
  const roads: Road[] = [];

  for (let r = 0; r < count; r++) {
    const points = 2 + Math.floor(rand() * 4);
    const centerline: Point2[] = [];
    for (let i = 0; i < points; i++) {
      centerline.push({
        x: (rand() * 2 - 1) * (МИН_ПОЛМИРА - 10),
        z: (rand() * 2 - 1) * (МИН_ПОЛМИРА - 10),
      });
    }
    roads.push({ type: roadTypeForLanes(1 + Math.floor(rand() * 4)), centerline });
  }
  return { roads, terrain };
}

interface Broken {
  seed: number;
  terrain: string;
  roads: number;
  reasons: string[];
}

const broken: Broken[] = [];
let worstAspect = 0;
let worstAspectSeed = 0;
let maxTriangles = 0;
let slowest = 0;

if (RUNNING && ONLY > 0) {
  const { roads, terrain } = layout(ONLY);
  console.log(`зерно ${ONLY}, рельеф ${terrain}, дорог ${roads.length}`);
  for (const r of roads) {
    console.log(`  ${r.type.name}: ` + r.centerline.map((p) => `(${p.x.toFixed(1)}, ${p.z.toFixed(1)})`).join(' '));
  }
  const world = buildWorld(roads, terrain);
  let t = performance.now();
  const surface = buildSurface(world);
  const ms = performance.now() - t;
  const report = inspect(world, surface);
  const tangled = crossingBorders(world);
  console.log(`  участков ${world.shapes.length}, узлов ${world.junctions.length}, треугольников ${report.triangles}, ${ms.toFixed(0)} мс`);
  console.log(`  дырок ${report.holes}, изнанкой ${report.downFacing}, плоских ${report.flat}, игла ${report.worstAspect.toFixed(0)}, полотно ${(report.paved * 100).toFixed(0)}%`);
  console.log(`  пересечений обязательных рёбер ${tangled.count}`);
  for (const w of tangled.where) console.log(`    ${w}`);
  process.exit(0);
}

for (let seed = 1; RUNNING && seed <= TRIES; seed++) {
  const { roads, terrain } = layout(seed);
  const started = performance.now();

  let report;
  const extra: string[] = [];
  try {
    const world = buildWorld(roads, terrain);
    if (world.shapes.length === 0) continue;
    const surface = buildSurface(world);
    report = inspect(world, surface);
    const tangled = crossingBorders(world);
    if (tangled.count > 0) extra.push(`${tangled.count} пересечений обязательных рёбер — ${tangled.where[0]}`);
  } catch (error) {
    broken.push({ seed, terrain, roads: roads.length, reasons: ['ПАДЕНИЕ: ' + String(error).split('\n')[0]] });
    continue;
  }
  slowest = Math.max(slowest, performance.now() - started);
  maxTriangles = Math.max(maxTriangles, report.triangles);
  if (report.worstAspect > worstAspect) {
    worstAspect = report.worstAspect;
    worstAspectSeed = seed;
  }

  const reasons = [...problems(report), ...extra];
  if (reasons.length > 0) broken.push({ seed, terrain, roads: roads.length, reasons });
}

const crossing = broken.filter((b) => b.roads > 1).length;

if (RUNNING) {
console.log(`обстрел: ${TRIES} случайных построек`);
console.log(`  сломалось            ${broken.length} (${((broken.length / TRIES) * 100).toFixed(0)}%)`);
console.log(`    из них с несколькими дорогами  ${crossing}`);
console.log(`    из них с одной дорогой         ${broken.length - crossing}`);
console.log(`  худшая вытянутость треугольника  ${worstAspect.toFixed(0)} : 1   (зерно ${worstAspectSeed})`);
console.log(`  самая тяжёлая постройка          ${maxTriangles.toLocaleString('ru-RU')} треугольников`);
console.log(`  самая долгая сборка              ${slowest.toFixed(0)} мс`);

const kinds = new Map<string, number>();
for (const b of broken) for (const r of b.reasons) {
  const kind = r.replace(/^\d+/, 'N');
  kinds.set(kind, (kinds.get(kind) ?? 0) + 1);
}
if (kinds.size > 0) {
  console.log('\nчто именно ломается:');
  for (const [kind, n] of [...kinds].sort((a, b) => b[1] - a[1])) console.log(`  ${String(n).padStart(4)} × ${kind}`);
  console.log('\nпервые сломанные постройки (зерно можно повторить):');
  for (const b of broken.slice(0, 5)) console.log(`  зерно ${b.seed}, рельеф ${b.terrain}, дорог ${b.roads}: ${b.reasons[0]}`);
}

if (broken.length > DEBT) process.exit(1);
if (DEBT > 0) {
  console.log(`\nдопущено ${DEBT} известных поломок (дыра 0 в STATE.md), сейчас ${broken.length}`);
  if (broken.length < DEBT) console.log(`стало лучше — опусти долг в tools/all.mjs до ${broken.length}`);
}
process.exit(0);
}
